<?php

declare(strict_types=1);

use OCP\Util;

Util::addScript(OCA\MyAppp\AppInfo\Application::APP_ID, OCA\MyAppp\AppInfo\Application::APP_ID . '-main');
Util::addStyle(OCA\MyAppp\AppInfo\Application::APP_ID, OCA\MyAppp\AppInfo\Application::APP_ID . '-main');

?>

<div id="myappp"></div>
